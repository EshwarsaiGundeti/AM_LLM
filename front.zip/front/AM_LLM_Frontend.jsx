import { useState, useEffect, useRef, useCallback } from "react";

const API_BASE = "http://localhost:8000";

// ── Palette & design tokens ───────────────────────────────────────────────
const C = {
  bg:        "#070B15",
  surface:   "#0F1629",
  surfaceHi: "#162040",
  border:    "#1E2D52",
  indigo:    "#4C6EF5",
  indigoLo:  "#2B3F8A",
  cyan:      "#00D4FF",
  cyanDim:   "#0097B8",
  text:      "#E8EEFF",
  muted:     "#6B7FA8",
  mutedHi:   "#9BADD0",
  danger:    "#FF4D6D",
  success:   "#00E5A0",
  warn:      "#FFB347",
};

// ── Inline styles ─────────────────────────────────────────────────────────
const S = {
  root: {
    fontFamily: "'IBM Plex Sans', system-ui, sans-serif",
    background: C.bg,
    color: C.text,
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    fontSize: 14,
  },
  header: {
    background: C.surface,
    borderBottom: `1px solid ${C.border}`,
    padding: "12px 24px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 16,
    flexShrink: 0,
  },
  logo: {
    display: "flex",
    alignItems: "center",
    gap: 10,
  },
  logoMark: {
    width: 32,
    height: 32,
    borderRadius: "50%",
    border: `2px solid ${C.cyan}`,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 13,
    color: C.cyan,
    fontFamily: "monospace",
    fontWeight: 700,
    boxShadow: `0 0 12px ${C.cyan}44`,
  },
  logoText: {
    fontSize: 16,
    fontWeight: 700,
    letterSpacing: "0.04em",
    color: C.text,
  },
  logoSub: {
    fontSize: 11,
    color: C.muted,
    fontFamily: "monospace",
  },
  headerStats: {
    display: "flex",
    gap: 20,
    alignItems: "center",
  },
  statPill: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    background: C.surfaceHi,
    border: `1px solid ${C.border}`,
    borderRadius: 20,
    padding: "4px 12px",
    fontSize: 12,
  },
  dot: (color) => ({
    width: 6,
    height: 6,
    borderRadius: "50%",
    background: color,
    boxShadow: `0 0 6px ${color}`,
  }),
  body: {
    display: "flex",
    flex: 1,
    overflow: "hidden",
    height: "calc(100vh - 57px)",
  },
  chatPanel: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    borderRight: `1px solid ${C.border}`,
    overflow: "hidden",
  },
  sessionBar: {
    padding: "10px 20px",
    background: C.surfaceHi,
    borderBottom: `1px solid ${C.border}`,
    display: "flex",
    alignItems: "center",
    gap: 10,
    fontSize: 12,
    flexShrink: 0,
  },
  messages: {
    flex: 1,
    overflowY: "auto",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: 16,
  },
  msg: (role) => ({
    display: "flex",
    flexDirection: role === "user" ? "row-reverse" : "row",
    gap: 10,
    alignItems: "flex-start",
  }),
  avatar: (role) => ({
    width: 30,
    height: 30,
    borderRadius: "50%",
    background: role === "user" ? C.indigoLo : "#0D2B2B",
    border: `1px solid ${role === "user" ? C.indigo : C.cyanDim}`,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 11,
    color: role === "user" ? C.indigo : C.cyan,
    fontFamily: "monospace",
    fontWeight: 700,
    flexShrink: 0,
  }),
  bubble: (role) => ({
    maxWidth: "72%",
    background: role === "user" ? C.indigoLo : C.surfaceHi,
    border: `1px solid ${role === "user" ? C.indigo + "55" : C.border}`,
    borderRadius: role === "user" ? "16px 4px 16px 16px" : "4px 16px 16px 16px",
    padding: "10px 14px",
    lineHeight: 1.6,
    color: C.text,
    wordBreak: "break-word",
  }),
  memTags: {
    display: "flex",
    flexWrap: "wrap",
    gap: 4,
    marginTop: 8,
  },
  memTag: {
    background: "#001A2A",
    border: `1px solid ${C.cyanDim}44`,
    borderRadius: 4,
    padding: "2px 7px",
    fontSize: 10,
    color: C.cyanDim,
    fontFamily: "monospace",
    cursor: "pointer",
  },
  inputBar: {
    padding: "16px 20px",
    background: C.surface,
    borderTop: `1px solid ${C.border}`,
    display: "flex",
    gap: 10,
    flexShrink: 0,
    alignItems: "flex-end",
  },
  textarea: {
    flex: 1,
    background: C.surfaceHi,
    border: `1px solid ${C.border}`,
    borderRadius: 10,
    color: C.text,
    padding: "10px 14px",
    fontSize: 14,
    fontFamily: "inherit",
    resize: "none",
    outline: "none",
    lineHeight: 1.5,
    minHeight: 42,
    maxHeight: 120,
    transition: "border-color 0.2s",
  },
  sendBtn: (enabled) => ({
    background: enabled ? C.indigo : C.indigoLo,
    border: "none",
    borderRadius: 10,
    color: enabled ? "#fff" : C.muted,
    padding: "10px 18px",
    cursor: enabled ? "pointer" : "not-allowed",
    fontSize: 14,
    fontWeight: 600,
    flexShrink: 0,
    transition: "background 0.2s",
    height: 42,
  }),
  sidebar: {
    width: 320,
    display: "flex",
    flexDirection: "column",
    overflow: "hidden",
    background: C.surface,
    flexShrink: 0,
  },
  sidebarTabs: {
    display: "flex",
    borderBottom: `1px solid ${C.border}`,
    flexShrink: 0,
  },
  tab: (active) => ({
    flex: 1,
    padding: "10px 0",
    background: "none",
    border: "none",
    borderBottom: active ? `2px solid ${C.cyan}` : "2px solid transparent",
    color: active ? C.cyan : C.muted,
    fontSize: 12,
    fontWeight: 600,
    cursor: "pointer",
    letterSpacing: "0.05em",
    transition: "color 0.2s",
  }),
  sidebarBody: {
    flex: 1,
    overflowY: "auto",
    padding: "14px",
    display: "flex",
    flexDirection: "column",
    gap: 10,
  },
  card: {
    background: C.surfaceHi,
    border: `1px solid ${C.border}`,
    borderRadius: 10,
    padding: 14,
  },
  cardLabel: {
    fontSize: 10,
    fontFamily: "monospace",
    color: C.muted,
    letterSpacing: "0.1em",
    textTransform: "uppercase",
    marginBottom: 6,
  },
  cardValue: {
    fontSize: 22,
    fontWeight: 700,
    color: C.cyan,
    fontFamily: "monospace",
  },
  statsGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 8,
  },
  memEntry: {
    background: C.surfaceHi,
    border: `1px solid ${C.border}`,
    borderRadius: 8,
    padding: 10,
    fontSize: 12,
    cursor: "pointer",
    transition: "border-color 0.2s",
  },
  memText: {
    color: C.text,
    lineHeight: 1.5,
    marginBottom: 6,
    display: "-webkit-box",
    WebkitLineClamp: 2,
    WebkitBoxOrient: "vertical",
    overflow: "hidden",
  },
  memMeta: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  scoreBar: (val) => ({
    height: 3,
    background: `linear-gradient(90deg, ${C.cyan} ${val * 100}%, ${C.border} ${val * 100}%)`,
    borderRadius: 2,
    marginTop: 6,
  }),
  badge: (color) => ({
    display: "inline-block",
    background: color + "22",
    border: `1px solid ${color}55`,
    borderRadius: 4,
    padding: "1px 6px",
    fontSize: 10,
    color: color,
    fontFamily: "monospace",
  }),
  emptyState: {
    textAlign: "center",
    color: C.muted,
    padding: "40px 20px",
    fontSize: 13,
  },
  sessionBtn: (variant) => ({
    padding: "7px 14px",
    borderRadius: 8,
    border: `1px solid ${variant === "danger" ? C.danger + "66" : C.border}`,
    background: variant === "danger" ? C.danger + "11" : C.surfaceHi,
    color: variant === "danger" ? C.danger : C.text,
    fontSize: 12,
    cursor: "pointer",
    fontWeight: 600,
    transition: "background 0.2s",
  }),
  toast: (type) => ({
    position: "fixed",
    bottom: 24,
    right: 24,
    background: type === "error" ? "#2A0A10" : "#001E14",
    border: `1px solid ${type === "error" ? C.danger : C.success}55`,
    color: type === "error" ? C.danger : C.success,
    borderRadius: 10,
    padding: "12px 18px",
    fontSize: 13,
    zIndex: 1000,
    maxWidth: 320,
    boxShadow: `0 4px 24px #00000088`,
  }),
  pulseRing: {
    display: "inline-block",
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: C.success,
    marginRight: 6,
    animation: "pulse 1.5s infinite",
  },
  section: {
    marginBottom: 4,
  },
  sectionTitle: {
    fontSize: 11,
    color: C.muted,
    fontFamily: "monospace",
    letterSpacing: "0.08em",
    textTransform: "uppercase",
    marginBottom: 8,
    padding: "0 2px",
  },
};

// ── Helper components ─────────────────────────────────────────────────────

function ScoreBar({ value }) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  const color = value > 0.7 ? C.success : value > 0.4 ? C.warn : C.danger;
  return (
    <div style={{ height: 3, background: C.border, borderRadius: 2, marginTop: 6 }}>
      <div style={{ height: 3, width: `${pct}%`, background: color, borderRadius: 2, transition: "width 0.4s" }} />
    </div>
  );
}

function MemoryCard({ mem, highlight }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      style={{
        ...S.memEntry,
        borderColor: highlight ? C.cyan + "88" : hovered ? C.indigo + "55" : C.border,
        boxShadow: highlight ? `0 0 10px ${C.cyan}22` : "none",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div style={S.memText}>{mem.text}</div>
      <ScoreBar value={mem.current_score} />
      <div style={{ ...S.memMeta, marginTop: 6 }}>
        <span style={S.badge(C.cyanDim)}>#{mem.id}</span>
        <span style={{ color: C.muted, fontSize: 10, fontFamily: "monospace" }}>
          {(mem.current_score * 100).toFixed(0)}% · {mem.access_count}× accessed
        </span>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }) {
  return (
    <div style={S.card}>
      <div style={S.cardLabel}>{label}</div>
      <div style={{ ...S.cardValue, color: color || C.cyan }}>{value}</div>
    </div>
  );
}

function Toast({ message, type, onDismiss }) {
  useEffect(() => {
    const t = setTimeout(onDismiss, 4000);
    return () => clearTimeout(t);
  }, [onDismiss]);
  return (
    <div style={S.toast(type)} onClick={onDismiss}>
      {type === "error" ? "⚠ " : "✓ "}{message}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────
export default function App() {
  const [sessionId, setSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [queryCount, setQueryCount] = useState(0);
  const [memories, setMemories] = useState([]);
  const [stats, setStats] = useState(null);
  const [activeTab, setActiveTab] = useState("memories");
  const [highlightIds, setHighlightIds] = useState([]);
  const [toast, setToast] = useState(null);
  const [maintenanceLast, setMaintenanceLast] = useState(null);
  const [backendOk, setBackendOk] = useState(null);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  // ── Auto-scroll ──
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ── Health check ──
  useEffect(() => {
    fetch(`${API_BASE}/health`)
      .then(r => r.ok ? r.json() : null)
      .then(d => setBackendOk(!!d))
      .catch(() => setBackendOk(false));
  }, []);

  // ── Poll stats every 5s when in session ──
  useEffect(() => {
    if (!sessionId) return;
    fetchMemories();
    fetchStats();
    const iv = setInterval(() => { fetchStats(); }, 5000);
    return () => clearInterval(iv);
  }, [sessionId]);

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type });
  }, []);

  async function fetchMemories() {
    try {
      const r = await fetch(`${API_BASE}/memories`);
      const d = await r.json();
      setMemories(d.memories || []);
    } catch {}
  }

  async function fetchStats() {
    try {
      const r = await fetch(`${API_BASE}/stats`);
      const d = await r.json();
      setStats(d);
    } catch {}
  }

  async function startSession() {
    try {
      const r = await fetch(`${API_BASE}/session/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const d = await r.json();
      setSessionId(d.session_id);
      setMessages([{
        role: "assistant",
        content: "Session started. I have access to long-term memory — tell me anything and I'll remember what matters.",
        memories: [],
      }]);
      setQueryCount(0);
      showToast("Session started");
    } catch (e) {
      showToast("Could not connect to backend. Is the server running on port 8000?", "error");
    }
  }

  async function closeSession() {
    if (!sessionId) return;
    try {
      await fetch(`${API_BASE}/session/close`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId }),
      });
      setSessionId(null);
      setMessages([]);
      setMemories([]);
      setStats(null);
      showToast("Session closed. Memories persisted.");
    } catch {
      showToast("Error closing session", "error");
    }
  }

  async function sendMessage() {
    if (!input.trim() || !sessionId || loading) return;
    const userMsg = input.trim();
    setInput("");
    setLoading(true);
    setHighlightIds([]);

    setMessages(prev => [...prev, { role: "user", content: userMsg, memories: [] }]);

    try {
      const r = await fetch(`${API_BASE}/query`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, query: userMsg }),
      });
      const d = await r.json();

      const ids = (d.memories_used || []).map(m => m.id);
      setHighlightIds(ids);

      setMessages(prev => [...prev, {
        role: "assistant",
        content: d.response,
        memories: d.memories_used || [],
        maintenance: d.maintenance_report,
      }]);

      setQueryCount(d.query_count);
      if (d.maintenance_report) setMaintenanceLast(d.maintenance_report);

      // Refresh memory store after ingestion
      setTimeout(() => { fetchMemories(); fetchStats(); }, 500);
    } catch (e) {
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "⚠ Could not reach the backend. Check that the server is running.",
        memories: [],
        error: true,
      }]);
    }
    setLoading(false);
  }

  function handleKey(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  // ── Sidebar tab content ──
  function renderSidebar() {
    if (activeTab === "stats") {
      return (
        <div style={S.sidebarBody}>
          <div style={S.statsGrid}>
            <StatCard label="LTM Memories" value={stats?.total_memories ?? "—"} />
            <StatCard label="FAISS Vectors" value={stats?.faiss_vectors ?? "—"} color={C.indigo} />
            <StatCard label="STM Turns" value={stats?.stm_turns ?? "—"} color={C.warn} />
            <StatCard label="Queries" value={queryCount} color={C.success} />
          </div>

          {maintenanceLast && (
            <>
              <div style={S.sectionTitle}>Last Maintenance</div>
              {maintenanceLast.compression && (
                <div style={S.card}>
                  <div style={S.cardLabel}>Compression</div>
                  <div style={{ fontSize: 12, color: C.mutedHi, lineHeight: 1.8 }}>
                    Clusters merged: <b style={{ color: C.text }}>{maintenanceLast.compression.clusters_merged}</b><br />
                    Before: <b style={{ color: C.text }}>{maintenanceLast.compression.memories_before}</b> →
                    After: <b style={{ color: C.text }}>{maintenanceLast.compression.memories_after}</b>
                  </div>
                </div>
              )}
              {maintenanceLast.forgetting && (
                <div style={S.card}>
                  <div style={S.cardLabel}>Forgetting</div>
                  <div style={{ fontSize: 12, color: C.mutedHi, lineHeight: 1.8 }}>
                    Evaluated: <b style={{ color: C.text }}>{maintenanceLast.forgetting.evaluated}</b><br />
                    Decayed: <b style={{ color: C.warn }}>{maintenanceLast.forgetting.decayed}</b> ·
                    Pruned: <b style={{ color: C.danger }}>{maintenanceLast.forgetting.pruned}</b>
                  </div>
                </div>
              )}
            </>
          )}

          <div style={{ ...S.card, marginTop: 4 }}>
            <div style={S.cardLabel}>Scoring Formula</div>
            <div style={{ fontFamily: "monospace", fontSize: 11, color: C.mutedHi, lineHeight: 1.8 }}>
              Score = α·Relevance + β·Frequency + γ·Novelty<br />
              <span style={{ color: C.indigo }}>α=0.50</span> · <span style={{ color: C.cyan }}>β=0.30</span> · <span style={{ color: C.warn }}>γ=0.20</span><br />
              Threshold: <span style={{ color: C.success }}>0.60</span>
            </div>
          </div>

          <div style={S.card}>
            <div style={S.cardLabel}>Decay Formula</div>
            <div style={{ fontFamily: "monospace", fontSize: 11, color: C.mutedHi }}>
              S_new = S_old × e<sup>-λΔt</sup><br />
              λ = <span style={{ color: C.cyan }}>0.01</span> · Min: <span style={{ color: C.danger }}>0.10</span>
            </div>
          </div>
        </div>
      );
    }

    // Memories tab
    return (
      <div style={S.sidebarBody}>
        {memories.length === 0 ? (
          <div style={S.emptyState}>
            <div style={{ fontSize: 28, marginBottom: 10 }}>◎</div>
            <div>No memories stored yet.</div>
            <div style={{ fontSize: 11, marginTop: 6, color: C.muted }}>
              Start a session and chat to populate LTM.
            </div>
          </div>
        ) : (
          <>
            <div style={{ fontSize: 11, color: C.muted, fontFamily: "monospace", marginBottom: 4 }}>
              {memories.length} {memories.length === 1 ? "entry" : "entries"} in LTM · sorted by score
            </div>
            {memories.map(m => (
              <MemoryCard key={m.id} mem={m} highlight={highlightIds.includes(m.id)} />
            ))}
          </>
        )}
      </div>
    );
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600;700&family=IBM+Plex+Mono:wght@400;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 4px; }
        @keyframes pulse { 0%,100% { opacity:1; transform:scale(1); } 50% { opacity:.5; transform:scale(1.3); } }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes glow { 0%,100% { box-shadow: 0 0 6px ${C.cyan}44; } 50% { box-shadow: 0 0 16px ${C.cyan}88; } }
      `}</style>

      <div style={S.root}>
        {/* ── Header ── */}
        <header style={S.header}>
          <div style={S.logo}>
            <div style={{ ...S.logoMark, animation: sessionId ? "glow 2s infinite" : "none" }}>AM</div>
            <div>
              <div style={S.logoText}>AM-LLM</div>
              <div style={S.logoSub}>Adaptive Memory-Augmented Language Model</div>
            </div>
          </div>

          <div style={S.headerStats}>
            <div style={S.statPill}>
              <div style={S.dot(backendOk === null ? C.warn : backendOk ? C.success : C.danger)} />
              <span style={{ color: C.mutedHi, fontSize: 11 }}>
                {backendOk === null ? "Checking..." : backendOk ? "Backend Online" : "Backend Offline"}
              </span>
            </div>
            {stats && (
              <div style={S.statPill}>
                <div style={S.dot(C.cyan)} />
                <span style={{ color: C.mutedHi, fontSize: 11, fontFamily: "monospace" }}>
                  {stats.total_memories} memories
                </span>
              </div>
            )}
            {sessionId && (
              <button style={S.sessionBtn("danger")} onClick={closeSession}>
                Close Session
              </button>
            )}
          </div>
        </header>

        {/* ── Body ── */}
        <div style={S.body}>
          {/* ── Chat Panel ── */}
          <div style={S.chatPanel}>
            {/* Session Bar */}
            <div style={S.sessionBar}>
              {sessionId ? (
                <>
                  <span style={S.pulseRing} />
                  <span style={{ color: C.mutedHi }}>Session:</span>
                  <span style={{ fontFamily: "monospace", color: C.cyan, fontSize: 11 }}>
                    {sessionId.slice(0, 8)}…{sessionId.slice(-4)}
                  </span>
                  <span style={{ color: C.border, margin: "0 4px" }}>|</span>
                  <span style={{ color: C.muted }}>{queryCount} queries</span>
                </>
              ) : (
                <span style={{ color: C.muted }}>No active session</span>
              )}
            </div>

            {/* Messages */}
            <div style={S.messages}>
              {!sessionId && messages.length === 0 && (
                <div style={{ ...S.emptyState, marginTop: 60 }}>
                  <div style={{
                    width: 64, height: 64, borderRadius: "50%",
                    border: `2px solid ${C.cyan}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    margin: "0 auto 20px", fontSize: 24,
                    color: C.cyan, boxShadow: `0 0 32px ${C.cyan}33`,
                  }}>◎</div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 8 }}>
                    Adaptive Memory AI
                  </div>
                  <div style={{ color: C.muted, maxWidth: 320, margin: "0 auto", lineHeight: 1.6 }}>
                    This system remembers what matters, forgets what doesn't, and compresses what overlaps.
                  </div>
                  <button
                    style={{
                      marginTop: 24, padding: "10px 24px", background: C.indigo,
                      border: "none", borderRadius: 10, color: "#fff",
                      fontSize: 14, fontWeight: 600, cursor: "pointer",
                    }}
                    onClick={startSession}
                  >
                    Start Session
                  </button>
                  {backendOk === false && (
                    <div style={{ marginTop: 16, fontSize: 12, color: C.danger }}>
                      ⚠ Backend unreachable — start FastAPI on port 8000
                    </div>
                  )}
                </div>
              )}

              {messages.map((msg, i) => (
                <div key={i} style={S.msg(msg.role)}>
                  <div style={S.avatar(msg.role)}>
                    {msg.role === "user" ? "U" : "AI"}
                  </div>
                  <div>
                    <div style={{
                      ...S.bubble(msg.role),
                      borderColor: msg.error ? C.danger + "44" : undefined,
                    }}>
                      {msg.content}
                      {/* Memory tags on assistant msgs */}
                      {msg.memories && msg.memories.length > 0 && (
                        <div style={S.memTags}>
                          {msg.memories.map(m => (
                            <span key={m.id} style={S.memTag} title={m.text}>
                              ◎ mem#{m.id} · {(m.similarity_score * 100).toFixed(0)}%
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    {/* Maintenance notice */}
                    {msg.maintenance && (
                      (msg.maintenance.compression?.clusters_merged > 0 || msg.maintenance.forgetting?.pruned > 0) && (
                        <div style={{
                          fontSize: 11, color: C.muted, marginTop: 4,
                          fontFamily: "monospace", paddingLeft: 4,
                        }}>
                          {msg.maintenance.compression?.clusters_merged > 0 &&
                            `⚙ compressed ${msg.maintenance.compression.clusters_merged} cluster(s)  `}
                          {msg.maintenance.forgetting?.pruned > 0 &&
                            `✕ forgot ${msg.maintenance.forgetting.pruned} stale memory/memories`}
                        </div>
                      )
                    )}
                  </div>
                </div>
              ))}

              {/* Typing indicator */}
              {loading && (
                <div style={S.msg("assistant")}>
                  <div style={S.avatar("assistant")}>AI</div>
                  <div style={{ ...S.bubble("assistant"), display: "flex", gap: 5, alignItems: "center", padding: "12px 16px" }}>
                    {[0, 1, 2].map(j => (
                      <div key={j} style={{
                        width: 6, height: 6, borderRadius: "50%", background: C.cyan,
                        animation: `pulse 1.2s ${j * 0.2}s infinite`,
                      }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div style={S.inputBar}>
              {!sessionId ? (
                <button
                  style={{ ...S.sendBtn(backendOk !== false), flex: 1, height: 42 }}
                  onClick={startSession}
                  disabled={backendOk === false}
                >
                  {backendOk === false ? "Backend Offline" : "Start Session to Chat"}
                </button>
              ) : (
                <>
                  <textarea
                    ref={textareaRef}
                    style={S.textarea}
                    placeholder="Send a message… (Enter to send, Shift+Enter for newline)"
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleKey}
                    rows={1}
                  />
                  <button
                    style={S.sendBtn(!!input.trim() && !loading)}
                    onClick={sendMessage}
                    disabled={!input.trim() || loading}
                  >
                    Send
                  </button>
                </>
              )}
            </div>
          </div>

          {/* ── Sidebar ── */}
          <div style={S.sidebar}>
            <div style={S.sidebarTabs}>
              {["memories", "stats"].map(t => (
                <button key={t} style={S.tab(activeTab === t)} onClick={() => {
                  setActiveTab(t);
                  if (t === "memories" && sessionId) fetchMemories();
                  if (t === "stats" && sessionId) fetchStats();
                }}>
                  {t === "memories" ? "◎ LTM Store" : "⟳ Stats & Internals"}
                </button>
              ))}
            </div>
            {renderSidebar()}
          </div>
        </div>
      </div>

      {toast && (
        <Toast message={toast.msg} type={toast.type} onDismiss={() => setToast(null)} />
      )}
    </>
  );
}
