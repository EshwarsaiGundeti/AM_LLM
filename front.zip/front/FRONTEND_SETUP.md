# AM-LLM Frontend Setup Guide

## Option A — Instant (no build, open HTML directly)

1. Copy `am_llm_frontend.html` anywhere on your machine.
2. Start the backend:
   ```bash
   cd backend/
   uvicorn main:app --reload
   ```
3. Open `am_llm_frontend.html` in Chrome/Edge/Firefox.
   > The file fetches React from a CDN, so you need an internet connection
   > the first time. After that, it's cached.

---

## Option B — React + Vite project (recommended for development)

### 1. Create the project

```bash
npm create vite@latest am-llm-ui -- --template react
cd am-llm-ui
npm install
```

### 2. Replace src/App.jsx

Copy the contents of `AM_LLM_Frontend.jsx` into `src/App.jsx`.

### 3. Clear default CSS

Replace `src/index.css` with:
```css
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body, #root { height: 100%; }
```

### 4. Enable CORS on the backend

Your `config.yaml` already has:
```yaml
server:
  cors_origins:
    - "http://localhost:5173"
    - "http://127.0.0.1:5173"
```
That's the Vite dev server — no changes needed.

### 5. Run both servers

Terminal 1 — Backend:
```bash
cd backend/
uvicorn main:app --reload --port 8000
```

Terminal 2 — Frontend:
```bash
cd am-llm-ui/
npm run dev
```

Open http://localhost:5173

---

## What the UI does

| Feature | Description |
|---------|-------------|
| **Start Session** | POSTs to `/session/start`, gets a UUID |
| **Chat** | Sends queries to `/query`, streams responses |
| **Memory tags** | Shows which LTM memories were used in each reply |
| **LTM Store tab** | Live list of all memories with score bars, highlighted when retrieved |
| **Internals tab** | Live stats, last maintenance report, formula display |
| **Close Session** | POSTs to `/session/close`, persists FAISS to disk |
| **Backend indicator** | Green dot when `/health` returns 200 |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| "Backend Offline" | Run `uvicorn main:app --reload` in `backend/` |
| CORS error in console | Check `config.yaml` cors_origins matches your frontend URL |
| Memories not appearing | Set your `GOOGLE_API_KEY` in `backend/.env` and restart |
| Mock mode active | Set `llm.use_mock: false` in `config.yaml` |
